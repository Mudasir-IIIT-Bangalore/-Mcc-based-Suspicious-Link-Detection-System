# Mcc-based-Suspicious-Link-Detection
Dataset and source code used in article "Mutual Clustering Coefficient-based Suspicious-link Detection Approach for Online Social Network  "


Dataset file: Data set containing similarity between friend pair based on features viz "  f2 -> work(w), f3-> education(e), f4-> home_town(ht) and f5-> current_city(cc) " along with label [Suspicious | Normal]. 
f1 -> holds the value for Mutual_clustering_Coefficient(Mcc).
